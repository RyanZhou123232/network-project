# Networker Demo

Static HTML/CSS/JavaScript demo for the scattered networking bubble interface.

## Structure

- `index.html` - page markup and UI shells.
- `src/data/profiles.js` - demo profile data and pending friend requests.
- `src/js/app.js` - interaction logic, sorting, search, panels, bubbles, and WebGL background.
- `src/css/style.css` - visual styling for the full demo.
- `assets/` - reserved for future images, icons, or media.

Open `index.html` directly in a browser to run the demo.
